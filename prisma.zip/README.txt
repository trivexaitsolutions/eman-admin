E-MAN Mitra — My Clients module

This ZIP contains:
1. views/mitra/clients.ejs        -> New My Clients list page
2. install-mitra-clients-module.js -> Safe automatic patcher for route + controller

Install:
1. Extract this ZIP directly inside the E-MAN project root folder.
   Example project root: D:\laragon\www\eman-admin

2. When Windows asks, allow it to merge/replace the files.
   It will add only this new view file and the installer script.

3. Open CMD in the project root and run:
   node install-mitra-clients-module.js

4. Restart backend:
   npm run dev

5. Open:
   http://localhost:4000/mitra/clients

What it adds:
- /mitra/clients route
- List of only the logged-in Mitra's own clients
- Search by client name, company, phone, email
- Individual/Company filter
- Primary work-site address, location captured status, requirement, verification status
- Uses the already-created shared navbar and toast partial

No delete, ban, or edit action is added in this step.
The installer creates .before_clients_module.bak backups of the two backend files before editing them.
