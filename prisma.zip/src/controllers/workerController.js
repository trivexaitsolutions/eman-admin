// src/controllers/workerController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const bcrypt = require('bcryptjs');

const listWorkers = async (req, res) => {
    try {
        const workers = await prisma.worker.findMany({
            include: { nakas: true, skills: true },
            orderBy: { id: 'desc' }
        });
        res.render('admin/workers/index', { workers });
    } catch (error) {
        console.error(error);
        res.status(500).send("Server Error");
    }
};

const showForm = async (req, res) => {
    try {
        const skills = await prisma.skill.findMany({ where: { isActive: true } });
        let worker = { isActive: true, nakas: [], skills: [] };
        let isEdit = false;
        
        if (req.params.id) {
            worker = await prisma.worker.findUnique({ 
                where: { id: parseInt(req.params.id) },
                include: { nakas: true, skills: true }
            });
            isEdit = true;
        }
        res.render('admin/workers/form', { worker, skills, isEdit, error: null });
    } catch (error) {
        res.redirect('/admin/workers');
    }
};
// src/controllers/workerController.js

const saveWorker = async (req, res) => {
    // 1. Add phone, email, and password to the destructured body
    const { 
        id, name, phone, email, password, dob, age, qualification, idProofType, idNumber, 
        address, pincode, bankDetails, upiId, upiNumber,
        nakaIds, skillIds 
    } = req.body;
    
    const isActive = req.body.isActive === 'on';

    try {
        const selectedNakas = [].concat(nakaIds || []).filter(id => id).map(nid => ({ id: parseInt(nid) }));
        const selectedSkills = [].concat(skillIds || []).filter(id => id).map(sid => ({ id: parseInt(sid) }));

        // 2. Add phone and email to workerData
        const workerData = {
            name,
            phone,
            email: email ? email.trim() : null, // Store null if left blank
            dob: new Date(dob),
            age: parseInt(age),
            qualification,
            idProofType,
            idNumber,
            address,
            pincode,
            bankDetails,
            upiId,
            upiNumber,
            isActive
        };

        // 3. Encrypt the password if one was provided
        if (password) {
            workerData.password = await bcrypt.hash(password, 10);
        }

        // Handle uploaded files
        if (req.files && req.files['photoUrl']) {
            workerData.photoUrl = '/uploads/photos/' + req.files['photoUrl'][0].filename;
        }
        if (req.files && req.files['consentVoiceUrl']) {
            workerData.consentVoiceUrl = '/uploads/voice/' + req.files['consentVoiceUrl'][0].filename;
        }

        if (id) {
            await prisma.worker.update({ 
                where: { id: parseInt(id) }, 
                data: { ...workerData, nakas: { set: selectedNakas }, skills: { set: selectedSkills } } 
            });
        } else {
            await prisma.worker.create({ 
                data: { ...workerData, nakas: { connect: selectedNakas }, skills: { connect: selectedSkills } } 
            });
        }
        
        res.redirect('/admin/workers');
    } catch (error) {
        console.error(error);
        if (error.code === 'P2002') {
            const skills = await prisma.skill.findMany({ where: { isActive: true } });
            // Let the user know exactly which unique field they duplicated!
            const target = error.meta.target;
            let errorMsg = "A worker with this ID Number already exists!";
            if (target.includes('phone')) errorMsg = "This Phone Number is already registered!";
            if (target.includes('email')) errorMsg = "This Email ID is already registered!";

            return res.render('admin/workers/form', { 
                worker: req.body, skills, isEdit: !!id, error: errorMsg 
            });
        }
        res.redirect('/admin/workers');
    }
};
// src/controllers/workerController.js

const loginWorker = async (req, res) => {
    // We expect 'loginId' from the app, which could be a phone OR email
    const { loginId, password } = req.body; 
    console.log("Login Attempt:", loginId,password); // Log the login ID for debugging
    
    try {
        // Find worker by matching either phone or email
        const worker = await prisma.worker.findFirst({ 
            where: { 
                OR: [
                    { phone: loginId },
                    { email: loginId }
                ]
            } 
        });
        console.log("worker found:", worker); // Log the worker object for debugging
        if (!worker) {
            return res.status(401).json({ success: false, message: "Invalid ID or password." });
        }

        const isMatch = await bcrypt.compare(password, worker.password);
        console.log("Password match:", isMatch); // Log the password match result for debugging
        if (!isMatch) {
            return res.status(401).json({ success: false, message: "Invalid ID or password." });
        }

        console.log("Login successful for worker:", worker.id); // Log successful login

        res.json({ 
            success: true, 
            worker: { id: worker.id, name: worker.name, phone: worker.phone } 
        });

    } catch (error) {
        console.error("Login API Error:", error);
        res.status(500).json({ success: false, message: "Server Error" });
    }
};

const getWorkerProfile = async (req, res) => {
    try {
        const worker = await prisma.worker.findUnique({
            where: { id: parseInt(req.params.id) },
            include: { nakas: true, skills: true }
        });

        if (!worker) {
            return res.status(404).json({ success: false, message: "Worker not found" });
        }

        res.json({ success: true, worker });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Server Error" });
    }
};

// Don't forget to export it!


const deleteWorker = async (req, res) => {
    try {
        await prisma.worker.delete({ where: { id: parseInt(req.params.id) } });
        res.redirect('/admin/workers');
    } catch (error) {
        res.redirect('/admin/workers');
    }
};

const getTodayPoolTimes = () => {
    const now = new Date();

    const startHour = parseInt(process.env.POOL_START_HOUR || "8");
    const startMinute = parseInt(process.env.POOL_START_MINUTE || "0");
    const endHour = parseInt(process.env.POOL_END_HOUR || "20");
    const endMinute = parseInt(process.env.POOL_END_MINUTE || "0");

    const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Kolkata",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    }).formatToParts(now);

    const year = parts.find((p) => p.type === "year").value;
    const month = parts.find((p) => p.type === "month").value;
    const day = parts.find((p) => p.type === "day").value;

    const pad = (num) => String(num).padStart(2, "0");

    const poolStart = new Date(
        `${year}-${month}-${day}T${pad(startHour)}:${pad(startMinute)}:00+05:30`
    );

    const poolEnd = new Date(
        `${year}-${month}-${day}T${pad(endHour)}:${pad(endMinute)}:00+05:30`
    );

    return { poolStart, poolEnd, now };
};

const getRemainingSeconds = (untilDate) => {
    if (!untilDate) return 0;

    const diff = new Date(untilDate).getTime() - new Date().getTime();
    return Math.max(0, Math.floor(diff / 1000));
};

const updateStatus = async (req, res) => {
    const {
        workerId,
        status,
        availabilityType = "FULL_DAY",
        availabilityHours,
    } = req.body;

    try {
        if (!workerId) {
            return res.status(400).json({
                success: false,
                message: "workerId required",
            });
        }

        const workerIdNumber = parseInt(workerId);

        // OFFLINE
        if (status === false || status === "false") {
            await prisma.worker.update({
                where: { id: workerIdNumber },
                data: {
                    isAvailable: false,
                    availabilityType: null,
                    availabilityStart: null,
                    availabilityHours: null,
                    availabilityUntil: null,
                    lastActive: new Date(),
                },
            });

            return res.json({
                success: true,
                message: "Aap Offline hain!",
            });
        }

        const { poolStart, poolEnd, now } = getTodayPoolTimes();

        let finalAvailabilityType = availabilityType || "FULL_DAY";
let finalAvailabilityHours = null;
let availabilityUntil = poolEnd;

// Full day ke liye 8 PM ke baad allow nahi
if (finalAvailabilityType === "FULL_DAY" && now >= poolEnd) {
    await prisma.worker.update({
        where: { id: workerIdNumber },
        data: {
            isAvailable: false,
            availabilityType: null,
            availabilityStart: null,
            availabilityHours: null,
            availabilityUntil: null,
            lastActive: new Date(),
        },
    });

    return res.status(400).json({
        success: false,
        message: "Full day pool has ended. You can use short hours availability.",
        code: "FULL_DAY_POOL_ENDED",
    });
}

        // FULL DAY
        if (finalAvailabilityType === "FULL_DAY") {
            availabilityUntil = poolEnd;
            finalAvailabilityHours = null;
        }

        // SHORT PERIOD
        else if (finalAvailabilityType === "SHORT_PERIOD") {
            finalAvailabilityHours = parseInt(availabilityHours);

            if (!finalAvailabilityHours || finalAvailabilityHours <= 0) {
                return res.status(400).json({
                    success: false,
                    message: "Please select valid hours.",
                });
            }

            availabilityUntil = new Date(
                now.getTime() + finalAvailabilityHours * 60 * 60 * 1000
            );

            
        }

        else {
            return res.status(400).json({
                success: false,
                message: "Invalid availability type.",
            });
        }

        const updatedWorker = await prisma.worker.update({
            where: { id: workerIdNumber },
            data: {
                isAvailable: true,
                availabilityType: finalAvailabilityType,
                availabilityStart: now,
                availabilityHours: finalAvailabilityHours,
                availabilityUntil,
                lastActive: now,
            },
        });

        return res.json({
            success: true,
            message:
                finalAvailabilityType === "FULL_DAY"
                    ? "Aap full day ke liye pool mein add ho gaye hain!"
                    : `Aap ${finalAvailabilityHours} hours ke liye pool mein add ho gaye hain!`,
            pool: {
                isAvailable: updatedWorker.isAvailable,
                availabilityType: updatedWorker.availabilityType,
                availabilityStart: updatedWorker.availabilityStart,
                availabilityHours: updatedWorker.availabilityHours,
                availabilityUntil: updatedWorker.availabilityUntil,
                remainingSeconds: getRemainingSeconds(updatedWorker.availabilityUntil),
            },
        });
    } catch (error) {
        console.error("Status update error:", error);
        res.status(500).json({
            success: false,
            error: "Status update nahi ho paya",
        });
    }
};

const getPoolStatus = async (req, res) => {
    try {
        const { workerId } = req.params;

        const worker = await prisma.worker.findUnique({
            where: { id: parseInt(workerId) },
            select: {
                id: true,
                isAvailable: true,
                availabilityType: true,
                availabilityStart: true,
                availabilityHours: true,
                availabilityUntil: true,
            },
        });

        if (!worker) {
            return res.status(404).json({
                success: false,
                message: "Worker not found",
            });
        }

        const now = new Date();

        if (
            worker.isAvailable &&
            worker.availabilityUntil &&
            new Date(worker.availabilityUntil) <= now
        ) {
            await prisma.worker.update({
                where: { id: parseInt(workerId) },
                data: {
                    isAvailable: false,
                    availabilityType: null,
                    availabilityStart: null,
                    availabilityHours: null,
                    availabilityUntil: null,
                    lastActive: now,
                },
            });

            return res.json({
                success: false,
                message: "Pool time ended. Worker is now offline.",
                code: "POOL_ENDED",
                isAvailable: false,
                remainingSeconds: 0,
            });
        }

        return res.json({
            success: true,
            isAvailable: worker.isAvailable,
            availabilityType: worker.availabilityType,
            availabilityStart: worker.availabilityStart,
            availabilityHours: worker.availabilityHours,
            availabilityUntil: worker.availabilityUntil,
            remainingSeconds: getRemainingSeconds(worker.availabilityUntil),
        });
    } catch (error) {
        console.error("Pool status error:", error);
        res.status(500).json({
            success: false,
            message: "Pool status fetch nahi ho paya",
        });
    }
};

const savePushToken = async (req, res) => {
    const { workerId, pushToken } = req.body;

    try {
        await prisma.worker.update({
            where: { id: parseInt(workerId) },
            data: { pushToken: pushToken }
        });
        
        console.log(`Worker ${workerId} ka Push Token save ho gaya!`);
        res.json({ success: true, message: "Token saved in Database!" });
    } catch (error) {
        console.error("Token save karne me error:", error);
        res.status(500).json({ success: false, message: "Database error" });
    }
};


const getWorkerDashboard = async (req, res) => {
    try {
        const { workerId } = req.params;

        const worker = await prisma.worker.findUnique({
            where: { id: parseInt(workerId) },
            include: {
                bookings: {
                    where: { status: 'COMPLETED' }
                }
            }
        });

        if (!worker) {
            return res.status(404).json({ success: false, message: "Worker nahi mila" });
        }

        // Calculate Total Earnings from completed jobs (Basic logic for now)
        // Note: Asli system me hum isko weekly basis par filter karenge
        const totalEarned = worker.bookings.reduce((sum, job) => sum + (job.amount || 600), 0);

        // Dummy calculations for E-MAN Score & Level (Jab tak Rating engine poora nahi hota)
        const emanScore = 4.2; 
        const level = "Silver Imaandar";

        res.json({ 
            success: true, 
            data: {
                id: worker.id,
                name: worker.name,
                emanId: `EMN-MUM-00${worker.id}`,
                score: emanScore,
                level: level,
                weeklyEarning: totalEarned > 0 ? totalEarned : 2400 // Default for demo
            }
        });

    } catch (error) {
        console.error("Worker Dashboard Error:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};


const showMitraAddForm = async (req, res) => {
    try {
        const skills = await prisma.skill.findMany({ where: { isActive: true } });
        const mitra = await prisma.mitra.findUnique({
            where: { id: req.user.id },
            include: { nakas: true }
        });

        res.render('mitra/add-worker', { 
            layout: false, 
            skills, 
            nakas: mitra.nakas || [], 
            error: req.query.error || null 
        });
    } catch (error) {
        res.redirect('/mitra/dashboard');
    }
};

const saveMitraWorker = async (req, res) => {
    const redirectWithError = (message) => {
        return res.redirect(
            `/mitra/workers/add?error=${encodeURIComponent(message)}`
        );
    };

    try {
        const {
            name,
            phone,
            email,
            password,
            dob,
            qualification,
            idProofType,
            idNumber,
            address,
            pincode,
            gender,
            heightCm,
            weightKg,
            bankDetails,
            upiId,
            upiNumber,
            skillIds,
            nakaIds,
        } = req.body;

        // --------------------------------------------------
        // 1. Required field validation
        // --------------------------------------------------
        if (!name?.trim()) {
            return redirectWithError("Worker name is required.");
        }

        if (!phone?.trim()) {
            return redirectWithError("Mobile number is required.");
        }

        if (!password?.trim()) {
            return redirectWithError("Password is required.");
        }

        if (!dob?.trim()) {
            return redirectWithError("Date of birth is required.");
        }

        if (!gender?.trim()) {
            return redirectWithError("Gender is required.");
        }

        if (!idProofType?.trim()) {
            return redirectWithError("Please select an ID proof type.");
        }

        if (!idNumber?.trim()) {
            return redirectWithError("ID proof number is required.");
        }

        if (!address?.trim()) {
            return redirectWithError("Address is required.");
        }

        if (!pincode?.trim()) {
            return redirectWithError("Pincode is required.");
        }

        if (
            heightCm === undefined ||
            heightCm === null ||
            String(heightCm).trim() === ""
        ) {
            return redirectWithError("Height is required.");
        }

        if (
            weightKg === undefined ||
            weightKg === null ||
            String(weightKg).trim() === ""
        ) {
            return redirectWithError("Weight is required.");
        }

        // --------------------------------------------------
        // 2. Mobile / Email / Pincode validation
        // --------------------------------------------------
        const cleanPhone = String(phone).replace(/\D/g, "");

        if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
            return redirectWithError(
                "Please enter a valid 10-digit Indian mobile number."
            );
        }

        const cleanEmail = email ? String(email).trim().toLowerCase() : null;

        if (
            cleanEmail &&
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)
        ) {
            return redirectWithError("Please enter a valid email address.");
        }

        const cleanPincode = String(pincode).replace(/\D/g, "");

        if (!/^\d{6}$/.test(cleanPincode)) {
            return redirectWithError("Pincode must contain exactly 6 digits.");
        }

        if (String(password).trim().length < 6) {
            return redirectWithError(
                "Password must contain at least 6 characters."
            );
        }

        // --------------------------------------------------
        // 3. DOB and calculated age validation
        // --------------------------------------------------
        const dobDate = new Date(dob);

        if (Number.isNaN(dobDate.getTime())) {
            return redirectWithError("Please enter a valid date of birth.");
        }

        const today = new Date();

        if (dobDate >= today) {
            return redirectWithError(
                "Date of birth must be earlier than today."
            );
        }

        let calculatedAge = today.getFullYear() - dobDate.getFullYear();
        const monthDifference = today.getMonth() - dobDate.getMonth();

        if (
            monthDifference < 0 ||
            (monthDifference === 0 && today.getDate() < dobDate.getDate())
        ) {
            calculatedAge--;
        }

        if (calculatedAge < 18 || calculatedAge > 100) {
            return redirectWithError(
                "Worker age must be between 18 and 100 years."
            );
        }

        // --------------------------------------------------
        // 4. Gender, Height, Weight and BMI validation
        // --------------------------------------------------
        const cleanGender = String(gender).trim().toUpperCase();
        const allowedGenders = ["MALE", "FEMALE", "OTHER"];

        if (!allowedGenders.includes(cleanGender)) {
            return redirectWithError(
                "Please select a valid gender: Male, Female or Other."
            );
        }

        const parsedHeightCm = Number(heightCm);
        const parsedWeightKg = Number(weightKg);

        if (
            !Number.isFinite(parsedHeightCm) ||
            parsedHeightCm < 80 ||
            parsedHeightCm > 250
        ) {
            return redirectWithError(
                "Height must be between 80 cm and 250 cm."
            );
        }

        if (
            !Number.isFinite(parsedWeightKg) ||
            parsedWeightKg < 20 ||
            parsedWeightKg > 300
        ) {
            return redirectWithError(
                "Weight must be between 20 kg and 300 kg."
            );
        }

        const heightInMeters = parsedHeightCm / 100;

        const calculatedBmi =
            Math.round(
                (parsedWeightKg / (heightInMeters * heightInMeters)) * 10
            ) / 10;

        // --------------------------------------------------
        // 5. ID proof format and separate field preparation
        // --------------------------------------------------
        const selectedProofType = String(idProofType)
            .trim()
            .toUpperCase();

        const allowedProofTypes = [
            "AADHAR",
            "AADHAAR",
            "PAN",
            "VOTING",
            "DRIVING",
        ];

        if (!allowedProofTypes.includes(selectedProofType)) {
            return redirectWithError("Please select a valid ID proof type.");
        }

        let finalProofType = selectedProofType;
        let cleanIdNumber = "";
        let aadhaarNumber = null;
        let panNumber = null;
        let otherIdNumber = null;

        // Aadhaar selected
        if (
            selectedProofType === "AADHAR" ||
            selectedProofType === "AADHAAR"
        ) {
            finalProofType = "AADHAR";

            cleanIdNumber = String(idNumber).replace(/\D/g, "");

            if (!/^\d{12}$/.test(cleanIdNumber)) {
                return redirectWithError(
                    "Aadhaar number must contain exactly 12 digits."
                );
            }

            aadhaarNumber = cleanIdNumber;

            const existingAadhaar = await prisma.worker.findFirst({
                where: {
                    OR: [
                        { aadhaarNumber: cleanIdNumber },
                        { idNumber: cleanIdNumber },
                    ],
                },
                select: { id: true },
            });

            if (existingAadhaar) {
                return redirectWithError(
                    "This Aadhaar number is already registered."
                );
            }
        }

        // PAN selected
        if (selectedProofType === "PAN") {
            cleanIdNumber = String(idNumber)
                .trim()
                .toUpperCase()
                .replace(/\s+/g, "");

            if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(cleanIdNumber)) {
                return redirectWithError(
                    "PAN format is invalid. Example: ABCDE1234F"
                );
            }

            panNumber = cleanIdNumber;

            const existingPan = await prisma.worker.findFirst({
                where: {
                    OR: [
                        { panNumber: cleanIdNumber },
                        { idNumber: cleanIdNumber },
                    ],
                },
                select: { id: true },
            });

            if (existingPan) {
                return redirectWithError(
                    "This PAN number is already registered."
                );
            }
        }

        // Voter ID / Driving License selected
        if (
            selectedProofType === "VOTING" ||
            selectedProofType === "DRIVING"
        ) {
            cleanIdNumber = String(idNumber)
                .trim()
                .toUpperCase()
                .replace(/\s+/g, "");

            if (cleanIdNumber.length < 5 || cleanIdNumber.length > 30) {
                return redirectWithError(
                    "Please enter a valid ID proof number."
                );
            }

            otherIdNumber = cleanIdNumber;

            const existingOtherId = await prisma.worker.findFirst({
                where: {
                    OR: [
                        { otherIdNumber: cleanIdNumber },
                        { idNumber: cleanIdNumber },
                    ],
                },
                select: { id: true },
            });

            if (existingOtherId) {
                return redirectWithError(
                    "This ID proof number is already registered."
                );
            }
        }

        // --------------------------------------------------
        // 6. Skills and Nakas validation
        // --------------------------------------------------
        const rawSkillIds = Array.isArray(skillIds)
            ? skillIds
            : skillIds
              ? [skillIds]
              : [];

        const rawNakaIds = Array.isArray(nakaIds)
            ? nakaIds
            : nakaIds
              ? [nakaIds]
              : [];

        const selectedSkillIds = rawSkillIds
            .map((id) => parseInt(id, 10))
            .filter((id) => Number.isInteger(id) && id > 0);

        const selectedNakaIds = rawNakaIds
            .map((id) => parseInt(id, 10))
            .filter((id) => Number.isInteger(id) && id > 0);

        if (selectedSkillIds.length === 0) {
            return redirectWithError("Please select at least one skill.");
        }

        if (selectedNakaIds.length === 0) {
            return redirectWithError("Please select at least one Naka.");
        }

        const activeSkills = await prisma.skill.findMany({
            where: {
                id: { in: selectedSkillIds },
                isActive: true,
            },
            select: { id: true },
        });

        if (activeSkills.length !== selectedSkillIds.length) {
            return redirectWithError(
                "One or more selected skills are invalid or inactive."
            );
        }

        const mitra = await prisma.mitra.findUnique({
            where: { id: req.user.id },
            include: {
                nakas: {
                    select: { id: true },
                },
            },
        });

        if (!mitra) {
            return redirectWithError("Mitra account was not found.");
        }

        const mitraNakaIds = mitra.nakas.map((naka) => naka.id);

        const hasUnauthorizedNaka = selectedNakaIds.some(
            (nakaId) => !mitraNakaIds.includes(nakaId)
        );

        if (hasUnauthorizedNaka) {
            return redirectWithError(
                "You can only assign workers to your own Naka."
            );
        }

        

        // --------------------------------------------------
        // 7. Video consent file
        // --------------------------------------------------
        let videoUrl = null;

        if (req.file) {
            videoUrl = `/uploads/consents/${req.file.filename}`;
        }

        // --------------------------------------------------
        // 8. Create worker
        // --------------------------------------------------
        const hashedPassword = await bcrypt.hash(String(password).trim(), 10);

        await prisma.worker.create({
            data: {
                name: String(name).trim(),
                phone: cleanPhone,
                email: cleanEmail,
                password: hashedPassword,

                dob: dobDate,
                age: calculatedAge,
                qualification: qualification?.trim() || null,

                idProofType: finalProofType,

                // Legacy field: selected proof number is still mirrored here
                idNumber: cleanIdNumber,

                // New future-ready separate fields
                aadhaarNumber,
                panNumber,
                otherIdNumber,

                address: String(address).trim(),
                pincode: cleanPincode,

                gender: cleanGender,
                heightCm: parsedHeightCm,
                weightKg: parsedWeightKg,
                bmi: calculatedBmi,

                bankDetails: bankDetails?.trim() || null,
                upiId: upiId?.trim() || null,
                upiNumber: upiNumber?.trim() || null,

                consentVoiceUrl: videoUrl,

                skills: {
                    connect: selectedSkillIds.map((id) => ({ id })),
                },

                nakas: {
                    connect: selectedNakaIds.map((id) => ({ id })),
                },

                mitraId: req.user.id,
                isActive: true,
            },
        });

        return res.redirect(
            "/mitra/dashboard?success=" +
            encodeURIComponent("Worker added successfully.")
        );
    } catch (error) {
        console.error("saveMitraWorker error:", error);

        if (error?.code === "P2002") {
            const target = Array.isArray(error.meta?.target)
                ? error.meta.target.join(", ")
                : String(error.meta?.target || "");

            if (target.includes("phone")) {
                return redirectWithError(
                    "This mobile number is already registered."
                );
            }

            if (target.includes("email")) {
                return redirectWithError(
                    "This email address is already registered."
                );
            }

            if (target.includes("aadhaarNumber")) {
                return redirectWithError(
                    "This Aadhaar number is already registered."
                );
            }

            if (target.includes("panNumber")) {
                return redirectWithError(
                    "This PAN number is already registered."
                );
            }

            if (target.includes("otherIdNumber")) {
                return redirectWithError(
                    "This ID proof number is already registered."
                );
            }

            return redirectWithError(
                "A worker with these details is already registered."
            );
        }

        return redirectWithError(
            "Unable to save worker. Please check all details and try again."
        );
    }
};


const listMitraWorkers = async (req, res) => {
    try {
        const mitraId = Number(req.user?.id);

        if (!Number.isInteger(mitraId) || mitraId <= 0) {
            return res.redirect(
                "/mitra/dashboard?error=" +
                encodeURIComponent("Mitra session was not found.")
            );
        }

        const search = String(req.query.search || "").trim();
        const status = String(req.query.status || "ALL").toUpperCase();

        const where = {
            mitraId,
        };

        if (status === "ACTIVE") {
            where.isActive = true;
        }

        if (status === "INACTIVE") {
            where.isActive = false;
        }

        if (search) {
            where.OR = [
                {
                    name: {
                        contains: search,
                    },
                },
                {
                    phone: {
                        contains: search,
                    },
                },
                {
                    email: {
                        contains: search,
                    },
                },
                {
                    idNumber: {
                        contains: search,
                    },
                },
            ];
        }

        const workers = await prisma.worker.findMany({
            where,
            include: {
                skills: {
                    orderBy: {
                        name: "asc",
                    },
                },
                nakas: {
                    orderBy: {
                        name: "asc",
                    },
                },
            },
            orderBy: {
                createdAt: "desc",
            },
        });

        return res.render("mitra/workers", {
            layout: false,
            workers,

            filters: {
                search,
                status:
                    status === "ACTIVE" || status === "INACTIVE"
                        ? status
                        : "ALL",
            },

            success_msg: req.query.success || null,
            error_msg: req.query.error || null,

            activePage: "workers",

            mitraName:
                req.user?.name ||
                req.user?.fullName ||
                "Mitra",
        });
    } catch (error) {
        console.error("Mitra Worker List Error:", error);

        return res.redirect(
            "/mitra/dashboard?error=" +
            encodeURIComponent("Workers list load nahi ho payi.")
        );
    }
};

module.exports = {
    getWorkerDashboard,
    listWorkers,
    showForm,
    saveWorker,
    deleteWorker,
    loginWorker,
    getWorkerProfile,
    updateStatus,
    getPoolStatus,
    savePushToken,
    showMitraAddForm,
    saveMitraWorker,
    listMitraWorkers
};