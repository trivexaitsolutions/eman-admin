// src/controllers/adminConflictController.js
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const getAllConflicts = async (req, res) => {
  try {
    const { status, raisedByType, date } = req.query;

    const where = {};

    // Status filter
    if (status && status !== "ALL") {
      where.status = status;
    }

    // Raised By filter: CLIENT / WORKER
    if (raisedByType && raisedByType !== "ALL") {
      where.raisedByType = raisedByType;
    }

    // Date filter
    if (date) {
      const start = new Date(date);
      const end = new Date(date);
      end.setDate(end.getDate() + 1);

      where.createdAt = {
        gte: start,
        lt: end,
      };
    }

    const conflicts = await prisma.conflict.findMany({
      where,
      include: {
        booking: {
          include: {
            customer: true,
            workers: true,
          },
        },
        timeline: {
          orderBy: {
            createdAt: "desc",
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    const formattedConflicts = conflicts.map((conflict) => {
      const booking = conflict.booking;
      const customer = booking?.customer || null;

      const worker =
        booking?.workers?.find(
          (w) => Number(w.id) === Number(conflict.workerId)
        ) || null;

      const totalBookingAmount = Math.round(Number(booking?.amount || 0));

      const perWorkerAmount =
        booking?.amount && booking?.workerCount
          ? Math.round(Number(booking.amount) / Number(booking.workerCount))
          : 0;

      let suggestedRefundAmount = 0;

      // Agar full booking cancel hui hai
      if (conflict.requestedAction === "CANCEL_BOOKING") {
        suggestedRefundAmount = totalBookingAmount;
      }

      // Agar ek worker cancel hua hai
      if (
        conflict.requestedAction === "CANCEL_WORKER" ||
        conflict.requestedAction === "CANCEL_DUTY"
      ) {
        suggestedRefundAmount = perWorkerAmount;
      }

      return {
        id: conflict.id,
        bookingId: conflict.bookingId,

        raisedByType: conflict.raisedByType,
        raisedById: conflict.raisedById,

        reason: conflict.reason,
        description: conflict.description,

        status: conflict.status,
        requestedAction: conflict.requestedAction,
        continueWork: conflict.continueWork,

        penaltyAmount: conflict.penaltyAmount || 0,

        totalBookingAmount,
        perWorkerAmount,
        suggestedRefundAmount,

        createdAt: conflict.createdAt,
        updatedAt: conflict.updatedAt,

        customer: customer
          ? {
              id: customer.id,
              name: customer.name,
              phone: customer.phone,
              email: customer.email,
            }
          : null,

        worker: worker
          ? {
              id: worker.id,
              name: worker.name,
              phone: worker.phone,
              email: worker.email,
            }
          : null,
      };
    });

    return res.render("admin/conflicts/index", {
      title: "Conflict Management",
      conflicts: formattedConflicts,
      filters: {
        status: status || "ALL",
        raisedByType: raisedByType || "ALL",
        date: date || "",
      },
    });
  } catch (error) {
    console.error("Get All Conflicts Error:", error);

    return res.status(500).send(`
      <h2>Server Error</h2>
      <p>Conflict list fetch karte waqt error aaya.</p>
      <pre>${error.message}</pre>
    `);
  }
};

module.exports = {
  getAllConflicts,
};