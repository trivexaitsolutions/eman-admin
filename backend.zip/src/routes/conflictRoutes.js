const express = require("express");
const router = express.Router();

const adminConflictController = require("../controllers/adminConflictController");

router.get("/", adminConflictController.getAllConflicts);

module.exports = router;