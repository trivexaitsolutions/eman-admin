// src/routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const conflictRoutes = require('./conflictRoutes');
const mitraRoutes = require('./mitraRoutes');
const { authBouncer } = require('../middlewares/authBouncer');
// const adminDashboardController = require('../controllers/adminDashboardController');

const employeeRoutes = require('./employeeRoutes');
const stateRoutes = require('./stateRoutes');
const cityRoutes = require('./cityRoutes');
const nakaRoutes = require('./nakaRoutes');
const skillRoutes = require('./skillRoutes');
const workerRoutes = require('./workerRoutes');
const adminDashboardController = require('../controllers/adminDashboardController');

router.get('/login', authController.getLoginPage);
router.post('/login', authController.login);

router.get('/logout', (req, res) => {
    res.clearCookie('token');
    if (req.session) req.session.destroy();
    res.redirect('/admin/login');
});

router.get(
    '/dashboard',
    authBouncer(['superadmin', 'admin', 'employee']),
    adminDashboardController.showDashboard
);

router.use('/employees', authBouncer(['superadmin', 'admin']), employeeRoutes);
router.use('/states', authBouncer(['superadmin', 'admin']), stateRoutes);
router.use('/cities', authBouncer(['superadmin', 'admin']), cityRoutes);
router.use('/nakas', authBouncer(['superadmin', 'admin']), nakaRoutes);
router.use('/skills', authBouncer(['superadmin', 'admin']), skillRoutes);

router.use('/workers', authBouncer(['superadmin', 'admin', 'employee']), workerRoutes);
router.use('/mitras', authBouncer(['superadmin', 'admin']), mitraRoutes);
router.use('/conflicts', authBouncer(['superadmin', 'admin', 'employee']), conflictRoutes);

module.exports = router;
