// src/routes/mitraPortalRoutes.js
const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const mitraPortalController = require('../controllers/mitraPortalController');
const mitraNakaController = require('../controllers/mitraNakaController');
const nakaVerificationUpload = require('../middlewares/nakaVerificationUpload');
const workerController = require('../controllers/workerController');
const mitraBouncer = require('../middlewares/mitraBouncer');
const leaveController = require('../controllers/leaveController');

// Multer Storage for Video Consents
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const dir = 'public/uploads/consents';
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        cb(null, 'consent-' + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });


// --- PUBLIC ROUTES ---
router.get('/login', (req, res) => res.render('mitra/login', { layout: false }));
router.post('/login', mitraPortalController.login);
router.get('/logout', mitraPortalController.logout);

// --- PROTECTED ROUTES ---
router.get('/dashboard', mitraBouncer, mitraPortalController.showDashboard);


// Mitra Naka Submission
// A Mitra can submit survey evidence, but cannot mark a Naka as VERIFIED.
// Submission creates a PENDING_VERIFICATION Naka and assigns it to that Mitra.
router.get('/nakas', mitraBouncer, mitraNakaController.listMyNakas);
router.get('/nakas/add', mitraBouncer, mitraNakaController.showAddNakaForm);
router.post(
    '/nakas/submit',
    mitraBouncer,
    nakaVerificationUpload.single('verificationPhoto'),
    mitraNakaController.submitNaka
);

// Conflict Management Routes
router.get('/conflicts', mitraBouncer, mitraPortalController.getMitraConflicts);

router.get('/conflicts/:id', mitraBouncer, mitraPortalController.getMitraConflictDetails);

router.post('/conflicts/:id/status', mitraBouncer, mitraPortalController.updateMitraConflictStatus);

// Leave Management
router.get('/leaves', mitraBouncer, leaveController.listMitraLeaves);
router.post('/leaves/apply', mitraBouncer, leaveController.applyMitraLeave);
router.post('/leaves/:id/cancel', mitraBouncer, leaveController.cancelMitraLeave);

// 🚀 WORKER ROUTES UPDATE: upload.single('videoConsent') add kiya
router.get(
    "/workers",
    mitraBouncer,
    workerController.listMitraWorkers
);
router.get('/workers/add', mitraBouncer, workerController.showMitraAddForm);

// Live lookup: returns the current assigned + operational Nakas for a PIN.
router.get(
    '/api/nakas/search',
    mitraBouncer,
    workerController.searchMitraNakasByPincode
);

router.get(
    '/workers/edit/:id',
    mitraBouncer,
    workerController.showMitraEditForm
);

router.post(
    '/workers/save',
    mitraBouncer,
    upload.single('videoConsent'),
    workerController.saveMitraWorker
);

router.post(
    '/workers/update/:id',
    mitraBouncer,
    upload.single('videoConsent'),
    workerController.updateMitraWorker
);

// Client Onboarding Routes
router.get('/clients', mitraBouncer, mitraPortalController.listMitraClients);

router.get('/clients/add', mitraBouncer, mitraPortalController.getAddClient);
router.post('/clients/add', mitraBouncer, mitraPortalController.postAddClient);

router.get('/clients/edit/:id', mitraBouncer, mitraPortalController.showEditClient);
router.post('/clients/update/:id', mitraBouncer, mitraPortalController.updateClient);



module.exports = router;